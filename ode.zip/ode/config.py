"""
Configuration file for AGHNN experiments
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class ModelConfig:
    """Model architecture configuration"""
    variant: str = 'small'  # tiny, small, base, large
    num_classes: int = 10
    threshold_easy: float = 0.35      # ← ADAPTIVE: Easy path if complexity < 0.35
    threshold_hard: float = 0.65      # ← ADAPTIVE: Hard path if complexity > 0.65
    dropout: float = 0.2


@dataclass
class TrainingConfig:
    """Training hyperparameters"""
    epochs: int = 200
    batch_size: int = 128
    learning_rate: float = 0.1
    momentum: float = 0.9
    weight_decay: float = 1e-4
    warmup_epochs: int = 5
    lr_schedule: str = 'cosine'  # cosine, step, multistep
    
    # Green regularization - improved scheduling for better convergence
        # Green regularization - improved scheduling for better convergence
    lambda_energy: float = 0.05
    lambda_energy_schedule: str = 'linear'  # linear, constant
    lambda_energy_start_epoch: int = 50     # ← NEW: Defer energy loss until epoch 50
    lambda_energy_start: float = 0.0        # ← Start at 0 (no penalty before epoch 50)
    lambda_energy_end: float = 0.05         # ← Gradually increase energy penalty after epoch 50
    
    
    # Knowledge distillation
    use_distillation: bool = True
    distill_temperature: float = 4.0
    distill_alpha: float = 0.3              # ← Reduced to prioritize main task loss
    
    # Data augmentation
    use_cutmix: bool = True
    cutmix_alpha: float = 1.0
    cutmix_prob: float = 0.5
    use_mixup: bool = True
    mixup_alpha: float = 0.2
    mixup_prob: float = 0.5
    label_smoothing: float = 0.1


@dataclass
class DataConfig:
    """Data configuration"""
    dataset: str = 'cifar10'
    data_dir: str = './data'
    img_size: int = 32
    num_workers: int = 4
    pin_memory: bool = True


@dataclass
class ExperimentConfig:
    """Complete experiment configuration"""
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    data: DataConfig = field(default_factory=DataConfig)
    
    # Experiment settings
    experiment_name: str = 'aghnn_experiment'
    seed: int = 42
    device: str = 'cuda'
    save_dir: str = './checkpoints'
    log_dir: str = './logs'
    eval_interval: int = 1
    save_interval: int = 5
    
    # Evaluation
    hard_routing: bool = False  # Use hard routing during evaluation
    profile_energy: bool = False


# Predefined configurations for different experiments

def get_cifar10_config() -> ExperimentConfig:
    """Configuration for CIFAR-10 experiments"""
    config = ExperimentConfig()
    config.data.dataset = 'cifar10'
    config.data.img_size = 32
    config.model.num_classes = 10
    config.training.epochs = 200
    config.experiment_name = 'aghnn_cifar10'
    return config


def get_cifar100_config() -> ExperimentConfig:
    """Configuration for CIFAR-100 experiments"""
    config = ExperimentConfig()
    config.data.dataset = 'cifar100'
    config.data.img_size = 32
    config.model.num_classes = 100
    config.model.variant = 'base'
    config.training.epochs = 300
    config.training.label_smoothing = 0.1
    config.experiment_name = 'aghnn_cifar100'
    return config


def get_imagenet_config() -> ExperimentConfig:
    """Configuration for ImageNet experiments"""
    config = ExperimentConfig()
    config.data.dataset = 'imagenet'
    config.data.img_size = 224
    config.model.num_classes = 1000
    config.model.variant = 'large'
    config.training.epochs = 90
    config.training.batch_size = 256
    config.training.learning_rate = 0.1
    config.experiment_name = 'aghnn_imagenet'
    return config


def get_ablation_config(
    use_adaptive: bool = True,
    use_green_reg: bool = True,
    use_distill: bool = True
) -> ExperimentConfig:
    """Configuration for ablation studies"""
    config = get_cifar10_config()
    
    if not use_adaptive:
        config.model.threshold_easy = 0.0
        config.model.threshold_hard = 0.0
        
    if not use_green_reg:
        config.training.lambda_energy = 0.0
        
    if not use_distill:
        config.training.use_distillation = False
        
    components = []
    if use_adaptive:
        components.append('adaptive')
    if use_green_reg:
        components.append('green')
    if use_distill:
        components.append('distill')
    
    config.experiment_name = f"ablation_{'_'.join(components) if components else 'baseline'}"
    return config
