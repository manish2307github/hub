"""
AGHNN - Adaptive Green Hybrid Neural Network
Main entry point for training and evaluation

Usage:
    python main.py train --config cifar10 --model small
    python main.py evaluate checkpoints/best.pth --config cifar10
    python main.py demo --model small
"""

import argparse
import torch
import torch.nn as nn

from models import AGHNN_Tiny, AGHNN_Small, AGHNN_Base, AGHNN_Large
from utils.energy import compute_flops, compute_parameters, measure_latency
from config import get_cifar10_config, get_cifar100_config, get_imagenet_config


def print_banner():
    """Print AGHNN banner"""
    banner = """
    ╔═══════════════════════════════════════════════════════════════╗
    ║                                                               ║
    ║     █████╗  ██████╗ ██╗  ██╗███╗   ██╗███╗   ██╗              ║
    ║    ██╔══██╗██╔════╝ ██║  ██║████╗  ██║████╗  ██║              ║
    ║    ███████║██║  ███╗███████║██╔██╗ ██║██╔██╗ ██║              ║
    ║    ██╔══██║██║   ██║██╔══██║██║╚██╗██║██║╚██╗██║              ║
    ║    ██║  ██║╚██████╔╝██║  ██║██║ ╚████║██║ ╚████║              ║
    ║    ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═══╝              ║
    ║                                                               ║
    ║    Adaptive Green Hybrid Neural Network                       ║
    ║    Energy-Efficient Deep Learning for Sustainable AI          ║
    ║                                                               ║
    ╚═══════════════════════════════════════════════════════════════╝
    """
    print(banner)


def get_model_by_name(name: str, num_classes: int = 10) -> nn.Module:
    """Get model by variant name"""
    models = {
        'tiny': AGHNN_Tiny,
        'small': AGHNN_Small,
        'base': AGHNN_Base,
        'large': AGHNN_Large
    }
    return models[name.lower()](num_classes=num_classes)


def cmd_train(args):
    """Train command"""
    from train import train
    
    # Load configuration
    if args.config == 'cifar10':
        config = get_cifar10_config()
    elif args.config == 'cifar100':
        config = get_cifar100_config()
    else:
        config = get_imagenet_config()
    
    # Override with arguments
    config.model.variant = args.model
    config.device = args.device
    config.data.data_dir = args.data_dir
    config.save_dir = args.save_dir
    
    if args.epochs:
        config.training.epochs = args.epochs
    if args.batch_size:
        config.training.batch_size = args.batch_size
    if args.lr:
        config.training.learning_rate = args.lr
    if args.save_interval:
        config.save_interval = args.save_interval

    resume_path = os.path.join(config.save_dir, 'latest.pth')
    if not os.path.exists(resume_path):
        resume_path = None
        
    print_banner()
    print(f"Starting training: {config.model.variant} on {config.data.dataset}")
    print(f"Epochs: {config.training.epochs}, Batch Size: {config.training.batch_size}")
    print("-" * 60)
    
    train(config, resume_path=resume_path)


def cmd_evaluate(args):
    """Evaluate command"""
    from evaluate import comprehensive_evaluation
    
    # Load configuration
    if args.config == 'cifar10':
        config = get_cifar10_config()
    elif args.config == 'cifar100':
        config = get_cifar100_config()
    else:
        config = get_imagenet_config()
    
    config.data.data_dir = args.data_dir
    
    print_banner()
    print(f"Evaluating checkpoint: {args.checkpoint}")
    print("-" * 60)
    
    comprehensive_evaluation(
        args.checkpoint,
        config,
        args.device,
        save_results=True,
        output_dir=args.output_dir
    )


def cmd_demo(args):
    """Demo command - show model capabilities"""
    print_banner()
    
    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")
    print("-" * 60)
    
    # Create model
    print(f"\nCreating AGHNN-{args.model.capitalize()} model...")
    model = get_model_by_name(args.model, num_classes=10).to(device)
    
    # Model statistics
    print("\n📊 Model Statistics:")
    param_info = compute_parameters(model)
    print(f"   Total Parameters: {param_info['total_formatted']}")
    print(f"   Trainable Parameters: {param_info['trainable_formatted']}")
    
    # FLOPs
    input_size = (1, 3, 32, 32)
    flops_info = compute_flops(model, input_size, device='cpu')
    print(f"   FLOPs: {flops_info['flops_formatted']}")
    
    # Latency (if GPU available)
    if device.type == 'cuda':
        print("\n⏱️ Latency Measurement:")
        latency_info = measure_latency(model, input_size, 'cuda')
        print(f"   Mean Latency: {latency_info['mean_ms']:.3f} ms")
        print(f"   Throughput: {latency_info['throughput']:.1f} images/sec")
    
    # Demo inference
    print("\n🔍 Demo Inference:")
    model.eval()
    dummy_input = torch.randn(1, 3, 32, 32).to(device)
    
    with torch.no_grad():
        outputs = model(dummy_input, return_complexity=True)
    
    print(f"   Input shape: {dummy_input.shape}")
    print(f"   Output shape: {outputs['logits'].shape}")
    print(f"   Complexity score: {outputs['complexity'].item():.3f}")
    
    if outputs['complexity'].item() < 0.3:
        print("   → Routed through EASY path (low complexity)")
    elif outputs['complexity'].item() > 0.7:
        print("   → Routed through HARD path (high complexity)")
    else:
        print("   → Routed through MEDIUM path")
    
    # Green Score estimate
    green_score = 94.0 / (flops_info['flops'] / 1e9 * param_info['total'] / 1e6) ** 0.5
    print(f"\n🌱 Estimated Green Score: {green_score:.3f}")
    
    print("\n" + "=" * 60)
    print("Demo completed! Use 'python main.py train' to start training.")
    print("=" * 60)


def cmd_info(args):
    """Information about model variants"""
    print_banner()
    
    print("\n📋 AGHNN Model Variants:\n")
    
    variants = [
        ('Tiny', AGHNN_Tiny, "Edge devices, IoT"),
        ('Small', AGHNN_Small, "Mobile applications"),
        ('Base', AGHNN_Base, "Standard tasks"),
        ('Large', AGHNN_Large, "Maximum accuracy")
    ]
    
    for name, model_fn, use_case in variants:
        model = model_fn(num_classes=10)
        param_info = compute_parameters(model)
        flops_info = compute_flops(model, (1, 3, 32, 32), device='cpu')
        
        print(f"  AGHNN-{name}:")
        print(f"    Parameters: {param_info['total_formatted']}")
        print(f"    FLOPs: {flops_info['flops_formatted']}")
        print(f"    Use case: {use_case}")
        print()
    
    print("\n🌱 Key Features:")
    print("  • Adaptive computation based on input complexity")
    print("  • Green regularization for energy efficiency")
    print("  • Knowledge distillation from hard to easy path")
    print("  • Sparse attention for reduced computation")
    print("  • Depthwise separable convolutions")


def main():
    parser = argparse.ArgumentParser(
        description='AGHNN - Adaptive Green Hybrid Neural Network',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py train --config cifar10 --model small
  python main.py evaluate checkpoints/best.pth
  python main.py demo --model base
  python main.py info
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Train command
    train_parser = subparsers.add_parser('train', help='Train AGHNN model')
    train_parser.add_argument('--config', type=str, default='cifar10',
                             choices=['cifar10', 'cifar100', 'imagenet'])
    train_parser.add_argument('--model', type=str, default='small',
                             choices=['tiny', 'small', 'base', 'large'])
    train_parser.add_argument('--epochs', type=int, default=None)
    train_parser.add_argument('--batch-size', type=int, default=None)
    train_parser.add_argument('--lr', type=float, default=None)
    train_parser.add_argument('--device', type=str, default='cuda')
    train_parser.add_argument('--data-dir', type=str, default='./data')
    train_parser.add_argument('--save-dir', type=str, default='./checkpoints')
    train_parser.add_argument('--save-interval', type=int, default=None,
                             help='Checkpoint save interval in epochs')
    train_parser.add_argument('--resume', type=str, default=None,
                             help="Checkpoint path to resume from or 'latest' to use save-dir/latest.pth")
    
    # Evaluate command
    eval_parser = subparsers.add_parser('evaluate', help='Evaluate trained model')
    eval_parser.add_argument('checkpoint', type=str, help='Path to checkpoint')
    eval_parser.add_argument('--config', type=str, default='cifar10',
                            choices=['cifar10', 'cifar100', 'imagenet'])
    eval_parser.add_argument('--device', type=str, default='cuda')
    eval_parser.add_argument('--data-dir', type=str, default='./data')
    eval_parser.add_argument('--output-dir', type=str, default='./evaluation_results')
    
    # Demo command
    demo_parser = subparsers.add_parser('demo', help='Demo model capabilities')
    demo_parser.add_argument('--model', type=str, default='small',
                            choices=['tiny', 'small', 'base', 'large'])
    demo_parser.add_argument('--device', type=str, default='cuda')
    
    # Info command
    info_parser = subparsers.add_parser('info', help='Show model information')
    
    args = parser.parse_args()
    
    if args.command == 'train':
        cmd_train(args)
    elif args.command == 'evaluate':
        cmd_evaluate(args)
    elif args.command == 'demo':
        cmd_demo(args)
    elif args.command == 'info':
        cmd_info(args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
