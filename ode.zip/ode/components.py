"""
AGHNN Component Modules
Building blocks for the Adaptive Green Hybrid Neural Network
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


class DepthwiseSeparableConv(nn.Module):
    """
    Depthwise Separable Convolution
    Reduces computational cost by factorizing standard convolution
    """
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        stride: int = 1,
        padding: int = 1,
        bias: bool = False
    ):
        super().__init__()
        self.depthwise = nn.Conv2d(
            in_channels, in_channels, kernel_size,
            stride=stride, padding=padding, groups=in_channels, bias=bias
        )
        self.pointwise = nn.Conv2d(in_channels, out_channels, 1, bias=bias)
        self.bn = nn.BatchNorm2d(out_channels)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.depthwise(x)
        x = self.pointwise(x)
        x = self.bn(x)
        return x


class SqueezeExcitation(nn.Module):
    """
    Squeeze-and-Excitation attention module
    Adaptively recalibrates channel-wise features
    """
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        reduced_channels = max(channels // reduction, 8)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, reduced_channels, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(reduced_channels, channels, bias=False),
            nn.Sigmoid()
        )
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, _, _ = x.size()
        y = self.pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class EfficientStem(nn.Module):
    """
    Efficient stem block for initial feature extraction
    Uses depthwise separable convolutions for efficiency
    """
    def __init__(self, in_channels: int = 3, out_channels: int = 32):
        super().__init__()
        self.conv1 = nn.Conv2d(
            in_channels, out_channels, 3, stride=2, padding=1, bias=False
        )
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = DepthwiseSeparableConv(out_channels, out_channels)
        self.relu = nn.ReLU(inplace=True)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.relu(self.conv2(x))
        return x


class GreenResidualBlock(nn.Module):
    """
    Energy-efficient residual block
    Combines depthwise separable convolutions with SE attention
    """
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        expansion: float = 1.0
    ):
        super().__init__()
        hidden_channels = int(in_channels * expansion)
        
        self.use_residual = (stride == 1 and in_channels == out_channels)
        
        layers = []
        
        # Expansion
        if expansion != 1.0:
            layers.extend([
                nn.Conv2d(in_channels, hidden_channels, 1, bias=False),
                nn.BatchNorm2d(hidden_channels),
                nn.ReLU(inplace=True)
            ])
        
        # Depthwise
        layers.extend([
            nn.Conv2d(
                hidden_channels, hidden_channels, 3,
                stride=stride, padding=1, groups=hidden_channels, bias=False
            ),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True)
        ])
        
        # SE attention
        layers.append(SqueezeExcitation(hidden_channels))
        
        # Projection
        layers.extend([
            nn.Conv2d(hidden_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels)
        ])
        
        self.block = nn.Sequential(*layers)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.block(x)
        if self.use_residual:
            out = out + x
        return out


class ComplexityEstimator(nn.Module):
    def __init__(self, in_channels: int = 32, hidden_channels: int = 32):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, hidden_channels, 1)
        self.bn1 = nn.BatchNorm2d(hidden_channels)
        self.conv2 = nn.Conv2d(hidden_channels, hidden_channels * 2, 1)
        self.bn2 = nn.BatchNorm2d(hidden_channels * 2)
        self.pool = nn.AdaptiveAvgPool2d(1)
        # DEEPENED: 4-layer FC with ReLU for better discrimination
        self.fc1 = nn.Linear(hidden_channels * 2, hidden_channels * 2)
        self.fc2 = nn.Linear(hidden_channels * 2, hidden_channels)
        self.fc3 = nn.Linear(hidden_channels, 32)
        self.fc4 = nn.Linear(32, 1)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = self.pool(x).flatten(1)
        # DEEPENED: More FC layers enable better feature discrimination
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        complexity = torch.sigmoid(self.fc4(x)).squeeze(-1)
        return complexity

class SparseAttention(nn.Module):
    """
    Sparse attention module
    Reduces quadratic complexity by selecting top-k attention weights
    """
    def __init__(
        self,
        dim: int,
        num_heads: int = 8,
        top_k: int = 32,
        qkv_bias: bool = False
    ):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5
        self.top_k = top_k
        
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.proj = nn.Linear(dim, dim)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        # Compute attention scores
        attn = (q @ k.transpose(-2, -1)) * self.scale
        
        # Sparse selection: keep only top-k attention weights
        if self.top_k < N:
            top_k_vals, top_k_indices = torch.topk(attn, self.top_k, dim=-1)
            sparse_attn = torch.zeros_like(attn).scatter_(-1, top_k_indices, top_k_vals)
            attn = sparse_attn
        
        attn = F.softmax(attn, dim=-1)
        
        out = (attn @ v).transpose(1, 2).reshape(B, N, C)
        out = self.proj(out)
        return out


class AdaptiveFusion(nn.Module):
    """
    Fuses outputs from easy and hard paths
    Supports both soft (training) and hard (inference) routing
    Fixed to handle proper tensor shape broadcasting
    """
    def __init__(self, channels: int):
        super().__init__()
        self.norm = nn.LayerNorm(channels)
        
    def forward(
        self,
        easy_out: torch.Tensor,
        hard_out: torch.Tensor,
        complexity: torch.Tensor,
        hard_routing: bool = False,
        threshold: float = 0.5
    ) -> torch.Tensor:
        """
        Args:
            easy_out: Output from easy path [B, C]
            hard_out: Output from hard path [B, C]
            complexity: Complexity scores [B] (squeezed for broadcasting)
            hard_routing: If True, use hard selection; else soft mixing
            threshold: Threshold for hard routing decision
        """
        # Ensure complexity is [B] and reshape for proper broadcasting to [B, 1]
        if complexity.dim() > 1:
            complexity = complexity.squeeze(-1)
        complexity_expanded = complexity.unsqueeze(1)  # [B, 1] for broadcasting
        
        if hard_routing:
            # Hard routing for inference: select entire path output
            mask = (complexity > threshold).unsqueeze(1).float()  # [B, 1]
            out = mask * hard_out + (1 - mask) * easy_out
        else:
            # Soft routing for training (enables gradient flow)
            out = complexity_expanded * hard_out + (1 - complexity_expanded) * easy_out
        
        return self.norm(out)


class EasyPath(nn.Module):
    """
    Lightweight path for simple inputs
    Reduced channels and fewer layers
    """
    def __init__(
        self,
        in_channels: int,
        num_classes: int,
        base_channels: int = 32,
        num_blocks: list = [1, 1, 1]
    ):
        super().__init__()
        
        channels = [base_channels, base_channels * 2, base_channels * 4]
        
        self.stage1 = self._make_stage(in_channels, channels[0], num_blocks[0], stride=1)
        self.stage2 = self._make_stage(channels[0], channels[1], num_blocks[1], stride=2)
        self.stage3 = self._make_stage(channels[1], channels[2], num_blocks[2], stride=2)
        
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(channels[2], num_classes)
        
    def _make_stage(
        self,
        in_channels: int,
        out_channels: int,
        num_blocks: int,
        stride: int
    ) -> nn.Sequential:
        layers = [GreenResidualBlock(in_channels, out_channels, stride)]
        for _ in range(num_blocks - 1):
            layers.append(GreenResidualBlock(out_channels, out_channels))
        return nn.Sequential(*layers)
    
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.stage1(x)
        x = self.stage2(x)
        x = self.stage3(x)
        features = self.pool(x).flatten(1)
        logits = self.fc(features)
        return logits, features


class HardPath(nn.Module):
    """
    Full-capacity path for complex inputs
    Standard channels and more layers
    """
    def __init__(
        self,
        in_channels: int,
        num_classes: int,
        base_channels: int = 64,
        num_blocks: list = [2, 3, 3]
    ):
        super().__init__()
        
        channels = [base_channels, base_channels * 2, base_channels * 4]
        
        self.stage1 = self._make_stage(in_channels, channels[0], num_blocks[0], stride=1)
        self.stage2 = self._make_stage(channels[0], channels[1], num_blocks[1], stride=2)
        self.stage3 = self._make_stage(channels[1], channels[2], num_blocks[2], stride=2)
        
        # Additional attention refinement
        self.attention = SparseAttention(channels[2], num_heads=8)
        
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(channels[2], num_classes)
        
    def _make_stage(
        self,
        in_channels: int,
        out_channels: int,
        num_blocks: int,
        stride: int
    ) -> nn.Sequential:
        layers = [GreenResidualBlock(in_channels, out_channels, stride, expansion=1.5)]
        for _ in range(num_blocks - 1):
            layers.append(GreenResidualBlock(out_channels, out_channels, expansion=1.5))
        return nn.Sequential(*layers)
    
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.stage1(x)
        x = self.stage2(x)
        x = self.stage3(x)
        
        # Apply sparse attention
        B, C, H, W = x.shape
        x_flat = x.flatten(2).transpose(1, 2)  # B, HW, C
        x_flat = self.attention(x_flat)
        x = x_flat.transpose(1, 2).reshape(B, C, H, W)
        
        features = self.pool(x).flatten(1)
        logits = self.fc(features)
        return logits, features
